#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include <vector>
#include <algorithm>
#include <iomanip>
#include "scheduling.h" // Custom header file for process structure and comparator
using namespace std;



// Function to perform First-In-First-Out (FIFO) scheduling
void fifoScheduling(vector<Process>& processes, const string& outputFileName) {
    ofstream outputFile(outputFileName); // Open output file for writing results

    if (!outputFile) { // Check if file opened successfully
        cerr << "Error opening file for FIFO output!" << endl;
        return;
    }




    // Initialize variables for time tracking and statistics
    int currentTime = 0, completed = 0;
    int totalWaitingTime = 0, totalTurnaroundTime = 0, totalResponseTime = 0;
    int totalBurstTime = 0;

    for (auto& process : processes) {
        if (currentTime < process.arrivalTime) {
            currentTime = process.arrivalTime; // Wait until the process arrives
        }


        if (process.responseTime == -1) { 
            process.responseTime = currentTime - process.arrivalTime; // Set response time
        }

        process.waitingTime = process.responseTime;
        process.turnaroundTime = process.burstTime + process.waitingTime;


        currentTime += process.burstTime; // Update current time
        totalBurstTime += process.burstTime;



        // accumulate the statistics
        totalWaitingTime += process.waitingTime;
        totalTurnaroundTime += process.turnaroundTime;
        totalResponseTime += process.responseTime;

        completed++;
    }

    // calculate performance metrics
    int elapsedTime = currentTime;
    double throughput = (double)completed / elapsedTime;
    double cpuUtilization = (double)totalBurstTime / elapsedTime * 100.0;




    // write results to output file
    outputFile << fixed << setprecision(2);
    outputFile << "FIFO Scheduling Statistics:\n";
    outputFile << "Number of Processes: " << completed << "\n";
    outputFile << "Total Elapsed Time: " << elapsedTime << "\n";
    outputFile << "Throughput: " << throughput << "\n";
    outputFile << "CPU Utilization: " << cpuUtilization << "%\n";
    outputFile << "Average Waiting Time: " << (double)totalWaitingTime / completed << "\n";
    outputFile << "Average Turnaround Time: " << (double)totalTurnaroundTime / completed << "\n";
    outputFile << "Average Response Time: " << (double)totalResponseTime / completed << "\n";


    outputFile.close(); // Closes output file
}












// Function to perform Priority Scheduling
void priorityScheduling(vector<Process>& processes, const string& outputFileName) {
    ofstream outputFile(outputFileName); // Open output file for writing results

    if (!outputFile) { // Check if file opened successfully
        cerr << "Error opening file for Priority output!" << endl;
        return;
    }




    // Initialize variables for time tracking and statistics
    int currentTime = 0, completed = 0;
    int totalWaitingTime = 0, totalTurnaroundTime = 0, totalResponseTime = 0;
    int totalBurstTime = 0;

    // Priority queue for ready processes based on priority
    priority_queue<Process*, vector<Process*>, ComparePriority> readyQueue;

    size_t index = 0; // Index to track processes in input vector
    while (completed < processes.size()) {
        // Add processes to ready queue based on arrival time
        while (index < processes.size() && processes[index].arrivalTime <= currentTime) {
            readyQueue.push(&processes[index]);
            index++;
        }

        if (readyQueue.empty()) { // If no process is ready, increment time is started
            currentTime++;
            continue;
        }

        // Select the process with the highest priority
        Process* currentProcess = readyQueue.top();
        readyQueue.pop();

        if (currentProcess->responseTime == -1) {
            currentProcess->responseTime = currentTime - currentProcess->arrivalTime;
        }

        currentProcess->remainingTime--;
        currentTime++;

        if (currentProcess->remainingTime == 0) { // Process finished
            completed++;
            currentProcess->waitingTime = currentTime - currentProcess->arrivalTime - currentProcess->burstTime;
            currentProcess->turnaroundTime = currentProcess->waitingTime + currentProcess->burstTime;

            // Accumulate statistics
            totalWaitingTime += currentProcess->waitingTime;
            totalTurnaroundTime += currentProcess->turnaroundTime;
            totalResponseTime += currentProcess->responseTime;
            totalBurstTime += currentProcess->burstTime;
        } else {
            readyQueue.push(currentProcess); // Re-add to queue if not finished
        }
    }

    // Calculates the performance metrics
    int elapsedTime = currentTime;
    double throughput = (double)completed / elapsedTime;
    double cpuUtilization = (double)totalBurstTime / elapsedTime * 100.0;





    // Writes results to output file
    outputFile << fixed << setprecision(2);
    outputFile << "Priority Scheduling Statistics:\n";
    outputFile << "Number of Processes: " << completed << "\n";
    outputFile << "Total Elapsed Time: " << elapsedTime << "\n";
    outputFile << "Throughput: " << throughput << "\n";
    outputFile << "CPU Utilization: " << cpuUtilization << "%\n";
    outputFile << "Average Waiting Time: " << (double)totalWaitingTime / completed << "\n";
    outputFile << "Average Turnaround Time: " << (double)totalTurnaroundTime / completed << "\n";
    outputFile << "Average Response Time: " << (double)totalResponseTime / completed << "\n";

    outputFile.close(); // Close output file
}











// Main function to read input and execute scheduling algorithms
int main() {
    ifstream inputFile("testinput.txt"); // Open input file

    if (!inputFile) { // Checks if the file opened successfully
        cerr << "Error opening input file!" << endl;
        return 1;
    }

    vector<Process> processes; // Vector used to store process data
    string line;
    int id = 1;

    getline(inputFile, line); // Skips the header line

    // Parses the  input file line by line
    while (getline(inputFile, line)) {
        stringstream ss(line);
        int arrivalTime, burstTime, priority;
        ss >> arrivalTime >> burstTime >> priority;

        processes.push_back({id++, arrivalTime, priority, burstTime, burstTime}); // Adds processes

        if (processes.size() >= 500) { // Limits the  number of processes taken in
            break;
        }
    }







    // Sort processes by arrival time
    sort(processes.begin(), processes.end(), [](const Process& a, const Process& b) {
        return a.arrivalTime < b.arrivalTime;
    });

    fifoScheduling(processes, "fifo_output.txt"); // Run FIFO scheduling




    // Reset process attributes for priority scheduling
    for (auto& process : processes) {
        process.remainingTime = process.burstTime;
        process.waitingTime = 0;
        process.turnaroundTime = 0;
        process.responseTime = -1;
    }

    priorityScheduling(processes, "priority_output.txt"); // Run Priority scheduling

    inputFile.close(); // Close input file
    return 0;
}

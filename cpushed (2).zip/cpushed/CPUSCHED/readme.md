Process Scheduler Simulation
The CPU scheduling algorithms, FIFO Scheduling and Priority Scheduling with Preemption are used to simulate cpu scheduling. The program processes a dataset of processes and calculates scheduling statistics for the first 500 completed processes.

Features
Simulates FIFO Scheduling.
Simulates Priority Scheduling with preemption.
Calculates the following statistics:
Number of processes executed.
Total elapsed time.
Throughput.
CPU utilization.
Average waiting time.
Average turnaround time.
Average response time.

total elapsed time: The amount of time from initiation to termination of the application.
Throughput (Number of processes executed in one unit of CPU burst time) so you can calculate it using the formula: Total burst
time( It is the sum of all given burst length) / Total number of processes
CPU Utilization: The CPU Utilization measures the percentage of the time that the CPU is performing work so you can calculate it
using the formula: Total Burst Time/ Total elapsed time
Average waiting time: total waiting time / Number of processes
Turnaround time = Burst time + Waiting time or
Turnaround time = Exit time - Arrival time
Average turnaround time: Total turnaround time / No of processes
Response time = Time at which the process gets the CPU for the first time - Arrival time Average response
time: Total response time / No of processes




run the progran by using:   

//to compile the program make sure you are in the cpushed\CPUSCHED file then use               g++ "CPU Scheduling.cpp" -o scheduling    



//to run the program                           ./scheduling                                         

#ifndef SCHEDULING_H
#define SCHEDULING_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

//struct for process
struct Process {
    int id;
    int arrivalTime;
    int priority;
    int burstTime;
    int remainingTime;
    int waitingTime = 0;
    int turnaroundTime = 0;
    int responseTime = -1;
};

// Compares for priority-based scheduling
struct ComparePriority {
    bool operator()(const Process* a, const Process* b) {
        return a->priority > b->priority; 
    }
};

// Function prototypes
void fifoScheduling(vector<Process>& processes, const string& outputFileName);
void priorityScheduling(vector<Process>& processes, const string& outputFileName);

#endif // SCHEDULING_H
